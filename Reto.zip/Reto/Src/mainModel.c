#include <stdint.h>
#include "main.h"
#include "uart.h"
#include "lcd.h"
#include <stddef.h>
#include <stdio.h>              /* This ert_main.c example uses printf/fflush */
#include "EngTrModel.h"         /* Model's header file */
#include "rtwtypes.h"
#include "keypad.h"

#define USER_B1	( GPIOC->IDR & ( 0x1UL << 13U )) //GPIOC Pin 13

void USER_RCC_Init(void);
void USER_RCC_ClockEnable(void);
void USER_GPIO_Init(void);
void USER_USART1_Init();
void USER_TIM2_Init();
void USER_ADC1_Init(void);
void USER_ADC1_Enable(void);
int USER_ADC1_Start(void);
void USER_KEYAPD_Init(void);
void USER_Measure_Task1(void);
void USER_Step_Task2();
void USER_LCD_Task3();
void USER_TRANSMIT_Task4();
void Task1_Init(void);

volatile float throttle = 0.0;
char direction;

int main(void)
{
	Task1_Init();//Init KEYPAD y ADC1
	//Init Task 2: no hay. Ya lo incluye el modelo
	LCD_Init( );//Init Task 3
  	USER_USART1_Init(); //Init Task 4
  for(;;)
	{
	  USER_Measure_Task1();
	  USER_Step_Task2();
	  USER_LCD_Task3();
	  USER_TRANSMIT_Task4();
	}
}

void Task1_Init(){
	USER_TIM2_Init();
	KEYPAD_Init();
  	USER_ADC1_Enable();
}

void USER_Measure_Task1(){
	if(KEYPAD_ReadKey() == 50){
		USER_TIM2_Delay( (uint16_t)TIM_10MS_PSC, (uint16_t)TIM_10MS_CNT);//  10ms
		EngTrModel_U.Throttle = 1.45;
		EngTrModel_U.BrakeTorque = 200.0;
		direction = ' ';
	}
	else if (USER_ADC1_Start() > 0 && KEYPAD_ReadKey() == 0){
		EngTrModel_U.Throttle = USER_ADC1_Start();
		EngTrModel_U.BrakeTorque = 0.0;
		direction = ' ';
	}
	else if((KEYPAD_ReadKey() == 49) || (KEYPAD_ReadKey() == 51)){
		if(KEYPAD_ReadKey() == 49){
			direction = 'L';
		}
		else if(KEYPAD_ReadKey() == 51){
			direction = 'R';
		}
		else{
			direction = ' ';
		}
	}
	else{
		EngTrModel_U.Throttle = 0.0;
		EngTrModel_U.BrakeTorque = 0.0;
		direction= ' ';
	}
}

void USER_Step_Task2(){
	EngTrModel_step();
	USER_TIM2_Delay( (uint16_t)TIM_200MS_PSC, (uint16_t)TIM_200MS_CNT);//  500ms
}

void USER_TRANSMIT_Task4(){
	printf("%i,%i,%i,%i\n\r", (int)EngTrModel_Y.VehicleSpeed, (int)EngTrModel_Y.EngineSpeed, (int)EngTrModel_Y.Gear, USER_ADC1_Start());
}

void USER_LCD_Task3(){
	 LCD_Clear();
	 LCD_Set_Cursor(1, 1);
	 LCD_Put_Str("AC:");
	 LCD_Put_Num((int)USER_ADC1_Start());
	 if((int)USER_ADC1_Start() == 0){
		 LCD_Put_Str("0");
	 }
	 LCD_Set_Cursor(1,8);
	 LCD_Put_Str("VS:");
	 LCD_Put_Num((int)EngTrModel_Y.VehicleSpeed);
	 if((int)EngTrModel_Y.VehicleSpeed == 0){
		 LCD_Put_Str("0");
	 }
	 LCD_Set_Cursor(2,1);
	 LCD_Put_Str("ES: ");
	 if (EngTrModel_Y.EngineSpeed < 0) {
		 LCD_Put_Str("-");
		 LCD_Put_Num((int)-EngTrModel_Y.EngineSpeed);
	 } else {
		 LCD_Put_Num((int)EngTrModel_Y.EngineSpeed);
	 }
	 LCD_Set_Cursor(1,14);
	 LCD_Put_Str("G:");
	 LCD_Put_Num((int)EngTrModel_Y.Gear);

	 LCD_Set_Cursor(2,10);
	 LCD_Put_Str("DI: ");
	 LCD_Put_Char(direction);
	 //printf("Keypad:%i\r\n",KEYPAD_ReadKey());
	USER_TIM2_Delay( (uint16_t)TIM_200MS_PSC, (uint16_t)TIM_200MS_CNT);//  500ms
}

void USER_TIM2_Init(){
	//USER_RCC_Init();
	/* System Clock configuration for 64 Mhz */
	FLASH->ACR	&= ~( 0x5UL <<  0U );	//Two wait states latency, if SYSCLK > 48Mhz
	FLASH->ACR 	|=  ( 0x2UL <<  0U );	//Two wait states latency, if SYSCLK > 48Mhz

	RCC->CFGR	&= ~( 0x1UL << 16U )
				&  ~( 0x7UL << 11U )
				&  ~( 0x3UL <<  8U )
				&  ~( 0xFUL <<  4U );

	RCC->CFGR 	|= ( 0xFUL << 18U )
				|  ( 0x4UL <<  8U );
	RCC->CR		|= ( 0x1UL << 24U );
	while ( !(RCC->CR & ~( 0x1UL << 25U )));
	RCC->CFGR 	&= ~( 0x1UL << 0U );
	RCC->CFGR	|=  ( 0x2UL << 0U );
	while ( 0x8UL != ( RCC->CFGR & 0xCUL ));

	//USER_RCC_ClockEnable();
	//TIM2 Clock Enable
	RCC->APB1ENR |= ( 0x1UL << 0U );

	//USER_GPIO_Init()
	//TIMER INITIALIZATION/
	// Timer slave mode disabled
	TIM2->SMCR &= ~(0x1 << 0U)
			  &	 ~(0x1 << 1U)
			  &	 ~(0x1 << 2U);

	// Configure the counter mode, Upcounter and the overflow UEV-event
	TIM2->CR1 &= ~(0x1 << 6U)
			  &	 ~(0x1 << 5U)
			  &	 ~(0x1 << 4U)
			  &	 ~(0x1 << 1U);

	//Enable internal clock
	//TIM2->SMCR &= ~( 0x7UL << 0U );
	//UEV enabled
	TIM2->CR1  &= ~( 0x1UL << 1U );
	//Upcounter
	TIM2->CR1  &= ~( 0x1UL << 4U );
	//Edge-alingned mode
	TIM2->CR1  &= ~( 0x3UL << 5U );
}

void USER_TIM2_Delay(uint16_t prescaler, uint16_t counter){
	//Clear the timer UIF
	TIM2->SR   &= ~( 0x1UL << 0U );
	//Configure initial count and prescaler
	TIM2->CNT 	= counter;
	TIM2->PSC 	= prescaler;
	//Enable timer to start counting
	TIM2->CR1  |= ( 0x1UL << 0U );
	//Wait for overflow
	while (! ( TIM2->SR & ( 0x1UL << 0U ) ));
	//Stop timer
	TIM2->CR1  &= ~( 0x1UL << 0U );
}

// 50 ms delay
void USER_TIM_Delay3(uint32_t time) {
	// Set the CNT and PSC values
	time = time * 1000000;
	TIM2->PSC = ceil(time/(3.125*65536))-1;
	TIM2->CNT = 65536-(time/((TIM2->PSC+1)*3.125));

	// Clear the timer interrupt flag
	TIM2->SR  &= ~(0x1 << 0U);

	// Initialize Timer
	TIM2->CR1 |= (0x1 << 0U);

	while (!(TIM2->SR & (0x1UL << 0U)));

	// Initialize Timer
	TIM2->CR1 &= ~(0x1 << 0U);

}

void USER_ADC1_Enable(void){
  	//USER_RCC_ClockEnable();
	//IO port A clock enable
	RCC->APB2ENR |= ( 0x1UL << 2U );
	//ADC Clock Enable
	RCC->APB2ENR |= ( 0x1UL << 9U );
	//Adjust ADC input clock
	RCC->CFGR 	 |= ( 0x3UL << 14U);	// Prescaler 8

	//USER_GPIO_Init();
	//PA0 as analog input for potentiometer
	GPIOA->CRL &= ~( 0xFUL << 0 );

	//USER_ADC1_Init();
	//Select Independent Mode
	ADC1->CR1 	&= ~( 0xFUL << 16U );
	//Right Alignment and Continuous Conversion Mode
	ADC1->CR2 	|=  ( 0x1UL <<  1U );
	ADC1->CR2 	&= ~( 0x1UL << 11U );
	//Sample time of 1.5 cycles for Channel 0
	ADC1->SMPR2 &=  ~( 0x7UL << 0U );
	//1 Conversion for Regular Channels
	ADC1->SQR1	&= ~( 0xFUL << 20U );
	//Select Channel 0 for First Conversion
	ADC1->SQR3  &= ~( 0x1FUL << 0U );
	//Enable ADC Module
	ADC1->CR2	|=  ( 0x1UL << 0U );
	//Module Calibration
	ADC1->CR2 	|=  ( 0x1UL << 2U ); // Start calibration
	//Wait until calibration is complete
	while ((ADC1->CR2 & ( 0x1UL << 2U )));
}


int USER_ADC1_Start(void){
	//Conversion starts when this bit holds a value of 1 and a 1 is written to it
	ADC1->CR2	|=  ( 0x1UL << 0U );
	//Wait until conversion is done
	while (!(ADC1->SR & ( 0x1UL << 1U )));
	//Read value from
	uint16_t adc_value = ADC1->DR;
	//Reset conversion flag
	ADC1->SR &= ~( 0x1UL << 1U );
	//Return value to percentage
	return (adc_value / 4095.0) * 100;
}
