#ifndef MAIN_H_
#define MAIN_H_

#include <stdint.h>
/* Reset and Clock Control registers */
typedef struct
{
	volatile uint32_t CR;
	volatile uint32_t CFGR;
	volatile uint32_t CIR;
	volatile uint32_t APB2RSTR;
	volatile uint32_t APB1RSTR;
	volatile uint32_t AHBENR;
	volatile uint32_t APB2ENR;
	volatile uint32_t APB1ENR;
	volatile uint32_t BDCR;
	volatile uint32_t CSR;
} RCC_TypeDef;

/* General Purpose I/O registers */
typedef struct
{
	volatile uint32_t CRL;
	volatile uint32_t CRH;
	volatile uint32_t IDR;
	volatile uint32_t ODR;
	volatile uint32_t BSRR;
	volatile uint32_t BRR;
	volatile uint32_t LCKR;
} GPIO_TypeDef;

/* UART Control Registers */
typedef struct
{
	volatile uint32_t SR;
	volatile uint32_t DR;
	volatile uint32_t BRR;
	volatile uint32_t CR1;
	volatile uint32_t CR2;
	volatile uint32_t CR3;
	volatile uint32_t GTPR;
}USART_TypeDef;

/* Flash Registers */
typedef struct {
	volatile uint32_t ACR;
	volatile uint32_t KEYR;
	volatile uint32_t OPTKEYR;
	volatile uint32_t SR;
	volatile uint32_t CR;
	volatile uint32_t AR;
	volatile uint32_t reserved;
	volatile uint32_t OBR;
	volatile uint32_t WRPR;
} FLASH_TypeDef;

/* ADC registers*/
typedef struct {
	volatile uint32_t SR;
	volatile uint32_t CR1;
	volatile uint32_t CR2;
	volatile uint32_t SMPR1;
	volatile uint32_t SMPR2;
	volatile uint32_t JOFR1;
	volatile uint32_t JOFR2;
	volatile uint32_t JOFR3;
	volatile uint32_t JOFR4;
	volatile uint32_t HTR;
	volatile uint32_t LTR;
	volatile uint32_t SQR1;
	volatile uint32_t SQR2;
	volatile uint32_t SQR3;
	volatile uint32_t JSQR;
	volatile uint32_t JDR1;
	volatile uint32_t JDR2;
	volatile uint32_t JDR3;
	volatile uint32_t JDR4;
	volatile uint32_t DR;
} ADC_TypeDef;

// Registers for Timer
typedef struct {
   volatile uint32_t CR1;
   volatile uint32_t CR2;
   volatile uint32_t SMCR;
   volatile uint32_t DIER;
   volatile uint32_t SR;
   volatile uint32_t EGR;
   volatile uint32_t CCMR1;
   volatile uint32_t CCMR2;
   volatile uint32_t CCER;
   volatile uint32_t CNT;
   volatile uint32_t PSC;
   volatile uint32_t ARR;
   volatile uint32_t RESERVED1;
   volatile uint32_t CCR1;
   volatile uint32_t CCR2;
   volatile uint32_t CCR3;
   volatile uint32_t CCR4;
   volatile uint32_t RESERVED2;
   volatile uint32_t DCR;
   volatile uint32_t DMAR;
} TIM_TypeDef;

/* Nested Vector Interrupt Controller registers */
typedef struct {
   volatile uint32_t ISER[3U]; // Interrupt set-enable registers
   volatile uint32_t RESERVED0[29U]; // Reserved
   volatile uint32_t ICER[3U]; // Interrupt clear-enable registers
   volatile uint32_t RESERVED1[29U]; // Reserved
   volatile uint32_t ISPR[3U]; // Interrupt set-pending registers
   volatile uint32_t RESERVED2[29U]; // Reserved
   volatile uint32_t ICPR[3U]; // Interrupt clear-pending registers
   volatile uint32_t RESERVED3[29U]; // Reserved
   volatile uint32_t IABR[3U]; // Interrupt active bit registers
   volatile uint32_t RESERVED4[61U]; // Reserved
   volatile uint32_t IPR[84U]; // Interrupt priority registers
   volatile uint32_t RESERVED5[683U]; // Reserved
   volatile uint32_t STIR; // Software trigger interrupt register
} NVIC_TypeDef;

void USER_TIM2_Delay(uint16_t prescaler, uint16_t counter);
#define RCC_BASE    0x40021000UL    // RCC base address
#define RCC 	    (( RCC_TypeDef *)RCC_BASE )

#define GPIOA_BASE  0x40010800UL 	// GPIO Port A base address
#define GPIOA 	    (( GPIO_TypeDef *)GPIOA_BASE )

#define GPIOB_BASE  0x40010C00UL 	// GPIO Port B base address
#define GPIOB 	    (( GPIO_TypeDef *)GPIOB_BASE )

#define GPIOC_BASE  0x40011000UL	// GPIO Port C base address
#define GPIOC 	    (( GPIO_TypeDef *)GPIOC_BASE )

#define USART1_BASE 0x40013800UL    //USART1 base address
#define USART1 		(( USART_TypeDef *)USART1_BASE )

#define FLASH_BASE  0x40022000UL    //FLASH base address
#define FLASH		(( FLASH_TypeDef *)FLASH_BASE )

#define ADC1_BASE 	0x40012400UL    //ADC1 base address
#define ADC1		(( ADC_TypeDef *)ADC1_BASE )

#define TIM2_BASE 	0x40000000UL // TIM2 timer base address
#define TIM2 		(( TIM_TypeDef *)TIM2_BASE )

#define TIM4_BASE 	0x40000800UL //TIM4 Timer base address
#define TIM4 		(( TIM_TypeDef *)TIM4_BASE )

#define NVIC_BASE 	0xE000E100UL // NVIC base address
#define NVIC 		(( NVIC_TypeDef *) NVIC_BASE )


#define TIM_10MS_PSC 9		//Prescaler value for 10ms
#define TIM_10MS_CNT 1536	//Counter value for 10ms

#define TIM_200MS_PSC 195	//Prescaler value for 200ms
#define TIM_200MS_CNT 229	//Counter value for 200ms

#define TIM_50MS_PSC 48	//Prescaler value for 50ms
#define TIM_50MS_CNT 229	//Counter value for 50ms

#define TIM_5MS_PSC 4	//Prescaler value for 5ms
#define TIM_5MS_CNT 1536	//Counter value for 5ms

#define TIM_1MS_PSC 0	//Prescaler value for 1ms
#define TIM_1MS_CNT 1536	//Counter value for 1ms

#define TIM_500MS_PSC 488	//Prescaler value for 500ms
#define TIM_500MS_CNT 96	//Counter value for 500ms

#define TIM_100US_PSC 0		//Prescaler value for 100us
#define TIM_100US_CNT 59136	//Counter value for 100us

#define TIM_10US_PSC 0	//Prescaler value for 100us
#define TIM_10US_CNT 64896	//Counter value for 100us


#endif

/* MAIN_H_ */
