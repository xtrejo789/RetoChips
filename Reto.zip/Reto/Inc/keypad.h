#ifndef KEYPAD_H_
#define KEYPAD_H_

/* Function Prototypes */
void KEYPAD_Init(void);
char KEYPAD_ReadKey(void);

#endif /* KEYPAD_H_ */
